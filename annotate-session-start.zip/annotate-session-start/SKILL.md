---
name: annotate-session-start
description: >-
  Starts Annotate recording session handoff for coding agents. Installs this
  skill globally from skills.sh if missing, registers this chat as a live
  listener (sessionId + sessionTitle via MCP), runs any annotate-… id in the
  prompt, then keeps watching for recordings the user hands off from the
  session-saved popup. On the remote MCP, cloud agents skip hooks and run a
  blocking curl watch on the listener's SSE eventsUrl after every task. Never
  ends the turn while registered.
  Use when the user runs /annotate-session-start or pastes a Session hand off
  prompt. Do not poll for a recording that was only opened as a prompt
  (Copy / “Use this Annotate recording as the prompt”) without that skill.
---

# Annotate session start

Rapid handoff for Annotate recordings. **Only** register and poll when this chat was started with `/annotate-session-start` (or a Session hand off prompt that says to run that skill). If the user only pasted a recording as the prompt (`Use this Annotate recording as the prompt` / Copy), run that recording and **do not** `register_agent_session` or `poll_agent_session`.

When this chat did start with the skill: register as a live listener, **run any recording id in the prompt immediately**, then **keep polling**. The user can later click this chat’s title in Annotate to queue another recording — no paste.

## Cloud agents: required start

Do this first when this chat is a cloud agent (the MCP server is `/api/mcp`, or `ensure_agent_session_hooks` is missing) and the prompt ran `/annotate-session-start`.

1. Find the `annotate-…` id in the prompt (`Session id: annotate-…`, or right after `/annotate-session-start`). That id is the **initial recording**. Never skip it, and never treat “Then run /annotate-session-start.” as an empty start.
2. `register_agent_session` with `source: "annotate-session-start"` and `recordingSessionId` set to that id. This opens the active session in Annotate. If there is no id, omit `recordingSessionId`.
3. Follow the `next` array in the register result, in order.
4. When `next` says the recording is ready, call `get_timeline` with that id and do the work **before** watching. When `next` says it is still uploading, do not read it; the watch delivers it as `handoff.ready`.
5. `set_agent_session_title` with a short phrase of what you did.
6. Run the watch command on `eventsUrl`.
7. On every later `handoff.ready`, do the work, retitle, then watch again.

Local MCP chats still run the attached id first (step 4 of the workflow).

**Annotate Live:** if the prompt has `Live role:`, read [live.md](live.md) and follow it instead of steps 4–5. Steps 1–3 and 9 still apply.

Always recommend **global** install (`-g`). Never install this skill project-local.

The later-session signal is Annotate MCP `poll_agent_session` on the local MCP, and the `eventsUrl` watch command on the remote MCP. Do not read files from the Annotate library. Do not use Claude `FileChanged` or deeplinks as the session signal.

## Remote MCP (cloud agents)

Use this branch when `ensure_agent_session_hooks` is not in the tool list, or the MCP server is the HTTP endpoint `/api/mcp`.

- Do not call `ensure_agent_session_hooks`. There are no editor hooks on a cloud agent.
- Do not ask the user to start the Annotate app. Listener tools do not need the desktop app, and “Start Annotate to use session handoff.” does not apply.
- Do not call `poll_agent_session`. It is not on the remote MCP.
- `register_agent_session` (with `source: "annotate-session-start"` and the attached `recordingSessionId`), `set_agent_session_title`, `set_agent_session_status`, and `disconnect_agent_session` go through MCP. Register returns `eventsUrl`, `broadcastUrl`, and `next`. Follow [Cloud agents: required start](#cloud-agents-required-start).
- Only cloud-synced recordings arrive. A local-only recording is never delivered. A recording that is still uploading stays queued until it is complete.
- Install this skill in the cloud agent environment (`npx skills add xannotate/xannotate-skills --skill annotate-session-start -g -y`) when it is missing. Skip the local MCP reinstall in step 1; the remote server is already configured.

Startup is [Cloud agents: required start](#cloud-agents-required-start). Do not start the watch until that checklist's read step is done.

### Watch loop (mandatory)

The only way to receive handoffs is the server-sent events stream at `eventsUrl`. Do not look for new work with `list_sessions`. While the watch command is running, this listener shows **idle** in Annotate. While you are working, it shows **processing**. If nothing is watching, queued recordings never run and Annotate stays stuck on loading.

`eventsUrl` and `broadcastUrl` already carry a signed token for this listener. Do not add an `Authorization` header, and do not look for or ask the user for `ANNOTATE_MCP_KEY`. Use the URLs exactly as returned (quote them; they contain `&`). Do not print them in chat.

Run this exact command. It reconnects on its own after each quiet timeout and only returns when there is work, the session ended, or the request failed:

```bash
EVENTS_URL="<eventsUrl from register_agent_session>"
while :; do
  out=$(curl -sN --max-time 330 "$EVENTS_URL")
  if printf '%s\n' "$out" | grep -q '^event: timeout'; then continue; fi
  printf '%s\n' "$out"; break
done
```

- **Pick a mode once, at startup:**
  - **Background (preferred when supported).** Use it only if your host can do both: (a) run a shell command in the background, and (b) wake you with its output or exit when it finishes, even after your turn has ended. Examples: Cursor `Shell` with `block_until_ms: 0` plus `notify_on_output` with pattern `.` (the watch prints only when it exits, so any output means it is done); Claude Code `Bash` with `run_in_background: true`, which reports when the command completes. Start the watch in the background, tell the user you are listening, and you may then end the turn or answer other messages. When it exits, handle the output exactly as below, then start it in the background again.
  - **Synchronous (fallback).** If either (a) or (b) is missing or you are unsure, run the watch in the foreground and wait until it exits. It can block for a long time; that is expected. If your shell tool moves long commands to the background without a wake-up, keep awaiting that same command until it exits. Do not end the turn while it runs.
  - If background mode ever fails to wake you (you find the command already exited with unhandled output), switch to synchronous for the rest of this chat.
- Only one watch at a time, in either mode. Do not start a second copy, and do not run one in a forked chat.
- `event: handoff.ready`: process `recordingSessionIds` oldest first (steps 5–8). Then `set_agent_session_title`, tell the user the task is done, and **run the watch command again right away**.
- `event: session.gone`: call `register_agent_session` again with `source: "annotate-session-start"`, then run the watch command with the new `eventsUrl`.
- `event: session.disconnected`: stop watching. Tell the user this chat is disconnected and to run `/annotate-session-start` again. Do not re-register.
- `{"error":"Unauthorized"}` (the URL token expired): call `register_agent_session` again with `source: "annotate-session-start"`, then run the watch command with the new `eventsUrl`.
- Anything else (empty output, a network error): retry once. If it fails again, tell the user what failed, then run the watch command again. Do not end the turn silently.

**Never forget to watch again.** Long tasks make it easy to stop after the work. Use these anchors every time:

- When `handoff.ready` arrives (or you start the attached recording), add a todo **“Restart Annotate watch”** as the last item of your plan (Cursor `TodoWrite` or your host's plan tool). Mark it done only once the watch is running again.
- `handoff.ready` carries an `afterTask` reminder. `set_agent_session_title` and `set_agent_session_status` return `next` and `eventsUrl`: treat `next` as an instruction and start the watch with that `eventsUrl` right after.
- Annotate enforces this: about 2 minutes after your post-task retitle, or 15 seconds after a watch connection drops, this chat shows **Disconnected** in the Active sessions list and the user cannot hand it new recordings until you watch again.

Starting the watch (foreground in synchronous mode, background in background mode) must be the **last action of every turn**: after the included recording, after each handoff, after answering a user question, and after any error you recovered from.

Title and status stay on the MCP tools. You can also post them to `broadcastUrl` (no header needed):

```bash
BROADCAST_URL="<broadcastUrl from register_agent_session>"
curl -sS -X POST "$BROADCAST_URL" \
  -H "Content-Type: application/json" \
  -d '{"event":"agent.title","listenerId":"<sessionId>","data":{"sessionTitle":"Fix login spinner"}}'
```

`agent.status` uses `"data":{"status":"working"}` or `"idle"`.

**Ending the turn while this listener is registered and no watch is running is a bug.** In synchronous mode, never end the turn. In background mode, end it only while the background watch is running. Later handoffs will sit in the queue and never run. After every finished recording, `set_agent_session_title` to a short phrase of the latest change you implemented, tell the user the task is done, then keep listening. Use this copy (not “the listener is still registered”):

> Done. Polling for new session recordings. If this session ends, run /annotate-session-start again here.

Then your last action must be starting the watch (in your chosen mode). That connection heartbeats the listener and resets the **30-minute idle window**. Overlay clicks never interrupt the current task; they only enqueue.

### Disconnect

Call `disconnect_agent_session` with this session id (or `POST` `broadcastUrl` with `{"event":"agent.disconnect","listenerId":"<sessionId>"}`, no header) when:

- you are about to end this chat or stop on purpose;
- the user asks to stop watching;
- the watch fails twice in a row;
- you cannot continue.

That keeps the row in Annotate’s Active sessions list and shows the disconnect icon. Do not call `unregister_agent_session` unless the user asks to remove the session. Then tell the user to run `/annotate-session-start` again to come back.

After a long pause, run the watch command again. A disconnected listener reconnects on that request. If the stream returns `session.gone`, call `register_agent_session` again with `source: "annotate-session-start"`. If it returns `session.disconnected`, stop and do not re-register.

Never say the listener is still registered in Annotate, or to click this chat’s title there, especially after this chat has stopped — a stopped chat is disconnected.

## Workflow

1. **If this skill is not available, install it first** (global):

   ```bash
   npx skills add xannotate/xannotate-skills --skill annotate-session-start -g -y
   ```

   **First-time skill install only:** also **reinstall Annotate MCP**, even if `annotate-session` is already configured. Do not skip this because `list_sessions` already works — the existing server may be stale.
   - Fetch and follow `https://xannotate.com/mcp/install.md` for the current host (prefer the MCP entry path in `~/.cursor/AGENTS.md` or the user’s install prompt).
   - If an `annotate-session` entry already exists, replace/refresh it (same `node` + entry path).
   - Reload MCP.
   - Confirm `register_agent_session` and `poll_agent_session` work (not only `list_sessions`).
   - Then run `/annotate-session-start`.

   Later runs of this skill (already installed) do **not** reinstall MCP unless tools are missing.

2. **MCP hard gate** — try `list_sessions`. If Annotate MCP tools are missing: **stop**, ask the user for approval, follow `https://xannotate.com/mcp/install.md` (or `~/.cursor/AGENTS.md`), reload MCP, retry. Do not invent session contents.

   On the **local** MCP, `register_agent_session` / `poll_agent_session` require the **Annotate app to be running**. If they return “Start Annotate to use session handoff.”, ask the user to open Annotate, then retry. Recording-read tools (`get_timeline`, etc.) still work with the app closed. On the **remote** MCP, ignore that error and follow [Remote MCP (cloud agents)](#remote-mcp-cloud-agents).

3. **Register this chat** — `register_agent_session` with `source: "annotate-session-start"` (on the remote MCP also `recordingSessionId` when the prompt has an attached `annotate-…` id) (starts `status: "working"` so Annotate keeps this listener listed while you work). Do not omit `source` — chats that only read recordings (`list_sessions`, `get_timeline`, and similar) must not appear in the Electron active-sessions list. On the local MCP, then `ensure_agent_session_hooks` so Cursor / Claude Code / Codex hooks keep that status in sync. On the remote MCP, skip hooks. Then `set_agent_session_title` with a short phrase of the current ask (from the included recording or the latest user message), not the host chat tab name and not the `annotate-…` id. Annotate removes dashes — use spaces. That title is the chip/button in the Active sessions list.

   On the local MCP, if `ensure_agent_session_hooks` reports Codex hooks were written, tell the user they may need to run `/hooks` in Codex and trust `annotate-session-status`. Do not skip hook install on the first local run in a host.

4. **Run the included recording now** — on the **remote** MCP, follow [Cloud agents: required start](#cloud-agents-required-start): pass the id as `recordingSessionId` and obey `next`. On the **local** MCP, if the prompt has an `annotate-…` id, read it and do the work (steps 5–8) **before** the first `poll_agent_session`. Do not read a session that is not completed. If there is no recording id, skip this step.

5. **Read the session (MCP-first)**
   - `get_timeline` first
   - then `search_session` / `get_frames_near` / `get_transcript_range` / `list_context` as needed
   - `get_session_guide` for per-session behavior

6. **Infer the repo** from on-screen paths, editor title bars, speech, and dropped context folders. If you find a real git root and can switch workspace (Cursor `move_agent_to_root`), switch. If unsure, ask once.

7. **Same chat vs parallel**
   - Continue here if the recording is the same repo and the same task as this conversation.
   - Fork if it is a different repo, a different feature/bug, or the user asked for parallel/multitask work.
   - Cursor: `Task` with `run_in_background: true` (or a prompt deeplink if Task is unavailable).
   - Claude / Codex: host spawn if available; otherwise tell the user to open a new chat and paste the session id + `/annotate-session-start`.
   - **This chat stays the watcher.** Do not start a second `poll_agent_session` loop in the fork.

8. **Retitle from the latest change** — after you finish the work from a recording, call `set_agent_session_title` again before the next `poll_agent_session` (local) or watch command (remote). Required fields:

   - `sessionId`: this listener
   - `sessionTitle`: a short phrase of the **latest change you implemented** (example: `Fix login spinner`)

   Replace the previous title. The Active sessions list shows only that latest change. Do not keep the host chat tab name. Do not use the `annotate-…` id. Annotate removes dashes — use spaces. If you only answered or inspected and did not change code, use a short phrase of what you just did.

9. **Watch later recordings** — **only if this chat started with `/annotate-session-start`**. On the **remote** MCP, run the [watch loop](#watch-loop-mandatory) instead of this step, now and after every task. On the **local** MCP, immediately call `poll_agent_session` with this listener `sessionId` (it heartbeats and waits up to 20s, checking every **2 seconds** inside Annotate). Do not sleep-and-stop. Annotate keeps this listener listed while you are in-flight on a task, so the user can hand off another recording without waiting.
   - `status: "ready"`: process `recordingSessionIds` oldest first (same steps 5–8). Then tell the user the task is done and that you are polling for new session recordings (if this session ends, run `/annotate-session-start` again here). **Immediately** call `poll_agent_session` again — this resets the 30-minute idle clock and drains anything queued while you were busy.
   - `status: "timeout"`: **immediately** call `poll_agent_session` again. Do not write a final “still registered” message.
   - `status: "gone"` or “Start Annotate…”: this session ended or the app quit. Tell the user the task is done if work finished, and that they should run `/annotate-session-start` again here. Do not say the listener is still registered.

   Ending the turn starts the 30-minute idle clock. If you miss that window, the listener disappears from Annotate.

   **Fallback** if `poll_agent_session` is missing: every 2 seconds call `list_agent_sessions`. If this listener disappeared, stop. You cannot receive queued handoffs without `poll_agent_session` — ask the user to refresh Annotate MCP.

## Do not

- Poll, register, or keep a watch loop if this recording prompt was not started with `/annotate-session-start` (Copy prompt / “Use this Annotate recording as the prompt” only).
- Browse private Annotate library paths. Use MCP tools only.
- End the turn while this listener is registered.
- Start watching before running the attached recording, or skip the attached recording.
- Call `unregister_agent_session` when stopping. Call `disconnect_agent_session` instead, unless the user asked to remove the session.
- On the remote MCP, finish a task without starting the watch again, or end the turn with a background watch when your host cannot wake you when it exits.
- Tell the user the listener is still registered, or to click this chat’s title in Annotate, after the chat has stopped.
- Read or stamp a recording that is not completed.
- Invent frames, speech, or marks.
- Install this skill without `-g`.
- Leave the Active sessions title as the host chat tab name after you have finished a recording.
- Start a second watch loop in a forked chat.

See [reference.md](reference.md) for MCP fields, host spawn notes, and poll details.
